# BEETLE:BIT Week 1 — Mission Control

A static, card-based 90-minute lesson for KS2 and KS3 learners. Students learn the BBC micro:bit as the future controller for BEETLE:BIT, build in MakeCode, transfer their program by USB and test it on physical hardware. No sensor work is introduced.

## Student journey

1. Enter a hazardous-object rescue scenario.
2. Improve an ambiguous robot instruction.
3. Review the school Knowledge, Skills and Understanding model.
4. Identify the micro:bit as a tiny programmable computer.
5. Investigate official micro:bit V2 front and back diagrams.
6. Trace a button event through input–process–output.
7. Read an actual MakeCode block model, then predict and build a four-event status controller.
8. Connect, download and test the program on a physical micro:bit.
9. Use the school Learning Pit Stop to select an evidence-based phase.
10. Follow a matched support or challenge route.
11. Explain how the same control model transfers from LEDs to future robot actions.
12. After the mission debrief, early finishers can build three optional hardware games: Shake Dice, Rock · Paper · Scissors and Reaction Racer.

Only one lesson card is visible at a time. The WAGBA and Knowledge/Skills/Understanding statements remain visible throughout. Students enter a name and class on a landing screen; those details stay in the browser session. Progress is saved locally under a separate anonymous device key, and no student response is transmitted.

## Hosting

This folder is designed for GitHub Pages and requires no build process, server, database or account. Preserve the `assets` folder beside `index.html`, `styles.css` and `app.js`.

The landing screen includes a staff review path that unlocks every card without displaying teacher controls to students.

The MakeCode program images in `assets` were rendered using the official MakeCode block renderer so learners see the real block shapes, colours and nesting.

## Sources

- Micro:bit Educational Foundation: First lessons with MakeCode and the micro:bit
- Micro:bit Educational Foundation: Transfer code to the micro:bit
- Microsoft MakeCode: Rock Paper Scissors tutorial and official block renderer
- Micro:bit Educational Foundation: Official micro:bit V2 feature diagrams, CC BY-SA 4.0
- Cytron: BEETLE:BIT Resource Hub
- School-provided Types of Learning and Learning Pit Stop visuals
