# Year 8 · Term 1 Week 2 Project

### Left-sidebar layout · update 3.4

On screens at least 1000px wide, the lesson journey, progress bar and expanded WAGBA/KSU occupy a 280–300px left sidebar. The top toolbar contains only identity, saving, language, PDF and menu controls. The sidebar and activity scroll independently; moving to a new lesson card resets the activity scroll, not student work. Smaller screens stack the expanded panel above the activity rather than squeezing the learning card or hiding the objectives. This supersedes the tall sticky-header layout described in update 3.2.

48 non-browser checks pass. Browser visual verification remains outstanding; no publishing or GitHub push was performed.

### Matched KSU reflections · update 3.3

The Types of Learning and Learning Pitstop pages adapt the provided Year 10 reflection pattern to Smart Badge learning. Six matched statements cover two Knowledge checks (input/output and event triggers), two Skills checks (building in the chosen editor and testing), and two Understanding checks (code location/timing and simulator versus physical evidence).

Students see two checks at a time: Knowledge → Skills → Understanding → My next step. Before practical work they identify their starting points and choose a focus. Afterwards they revisit the same statements, compare prior responses, cite actual badge/test evidence and choose a specific next action. Mixed learning phases are valid; no overall score or automatic emotional classification is produced. “Not attempted” and connection difficulties are not treated as conceptual failure.

The single-column question style, evidence prompts, stage-dependent suggestions and before/after summaries follow the supplied Year 10 reference, with Year 8 language and device-specific examples. Mandarin, Korean and Malay translations cover statements, evidence prompts, choices and practice guidance. A short written explanation can use any language.

Include the new `reflections.js` with the other static files when publishing. Load it after `lesson.js` and before `views.js`. All new responses are registered for autosave, revision history, PDF reports and backup restore. Earlier `strategy`, `phase` and `nextMove` answers are preserved as older-version evidence, not silently converted into six new answers. Old completed reflection cards that lack the new responses are marked for review without locking navigation.

Verification: 47 non-browser regression checks passed, including every reflection subpage in all four languages, mixed stages, persistence, before/after report content, new backup fields and no-lockout progression. Live layout and print pagination were not visually verified in this update because local browser preview was blocked.

### Header and extension update · 13 September 2026

- WAGBA and full Knowledge, Skills and Understanding statements are displayed in the header, not behind a KSU button. The same objective source supplies the PDF report.
- Eight labelled stages show the current location and recorded/needs-review status, from Do Now to Review / PDF. A permanent Export PDF control is in the top toolbar. The progress bar counts recorded core work, not mastery or confirmed Teams submission.
- The full Extension page is encountered after Main Task 2 evidence and before Learning Pitstop. Students are invited to challenge themselves if there is time. They can choose among three levels, return for another challenge, or continue without a required extension submission.
- Existing v3 core indices, storage keys, responses and evidence are preserved. The extension landing page is not counted as completed work or added as an empty assessment section in reports.
- The header is sticky on standard laptop/tablet viewports. On very short screens (below 620px tall, including some high-zoom layouts), it remains expanded at the top but scrolls with the page so it cannot cover the activity. It never becomes a hidden button.
- Verification: 43 non-browser regression checks pass, including the revised route, visible header markup, unchanged saved core positions, extension backup recovery and report generation. Live visual preview was blocked by the browser tool's local-URL policy; responsive rendering and actual print pagination need a manual browser check. No GitHub push or deployment was performed.

## Smart Badge — Mission 1 (redesigned September 2026)

A static, one-card-at-a-time lesson. Students build a welcome icon and a Button A response, then test, explain and preserve evidence. There is no server, account system or build step for this lesson.

### Open or host

1. Extract the ZIP, retaining its folders.
2. Open `index.html` on a computer, or publish the folder to the existing school static site.
3. For GitHub Pages, keep these files together inside `year8-week2-project/`. With the repository’s existing Pages branch/folder deployment, the route is `…/year8-week2-project/`.
4. Commit/push using the school’s normal process when ready. This redesign does not publish or change Pages settings itself.

The existing repository also has unrelated framework starter folders (`app/`, `db/`, `worker/`, configuration and build files). They are not used by this static lesson and have been left unchanged. Do not configure a Next/Vinext build to serve this lesson. On Netlify/Vercel, use a static deployment with no build command and this folder as the publish directory.

Prefer HTTPS hosting for classroom iPads. Files opened through iPad Files/preview may not run JavaScript normally. Local-file storage and clipboard permissions also vary by managed browser. No guarantee of offline operation is made for the external editors.

### Student and teacher entry

- Students enter full name, class and support language, then select Start. Both name and class are required, but there is no inflexible two-word-name rule.
- Existing version 3 work can be resumed from the landing page or by using the same name and class.
- Enter `teacher` as the name to unlock all cards. Class may be blank. Teacher mode has separate storage and starts with sample device/editor choices, not fake learning results.
- `index.html?teacher=1` is an alternative hidden route. It pre-fills the entry fields; press Start.
- There are no teacher controls advertised in the student interface. This is a convenience route, not a secure authentication system.

### Lesson spine and approximate 60-minute use

| Time | Stage | What students do |
|---|---|---|
| 0–4 min | Do Now | Read the badge example; predict the A response. |
| 4–6 min | Types of learning / how to get better | Record six starting points (two per K/S/U group), then choose one focus. |
| 6–20 min | Main Task 1 | Choose the correct route; run a tiny working model; choose an icon and initials. |
| 20–48 min | Main Task 2 | Add the A response; test restart and A; transfer; capture evidence. |
| Within practical time | Extension | Choose a challenge if time; continue to the Pitstop without a completion requirement. |
| 48–51 min | Learning Pitstop | Revisit the six checks, compare starting points, cite evidence and choose one next action. |
| 51–56 min | Plenary | Explain the event using the student’s program; predict a change. |
| 56–60 min | Review, submission and pack away | Save PDF/backup, submit to Teams, return equipment. |

The 12 core cards sit inside these stages; they are not 12 separate worksheets. Only one card is rendered at a time. Picture guides, full code explanations and the report expand on request. A little vertical scrolling is intentionally allowed for larger text, translations and code rather than clipping content to an exam-sized viewport.

An Extension page appears automatically after the evidence card and before Learning Pitstop. If there is time, students should use it to challenge themselves. Students choose Level 1 (another button event), Level 2 (diagnose a misplaced instruction, using A4 paper if helpful), or Level 3 (user test and improvement). After one, they can choose another. Extensions never block the pitstop or plenary. Budget 5–15 minutes from the practical window for early finishers; do not add all extension time on top of 60 minutes.

### Device and code routes

- **iPad + MakeCode Blocks:** micro:bit iOS app → Create Code → MakeCode Blocks. Physical transfer is via Bluetooth/app prompts.
- **iPad + MakeCode Python:** the same app/editor, then the menu beside JavaScript → Python. Uses `basic.show_icon`, `basic.show_string` and button-event functions.
- **Laptop + MakeCode Blocks/Python:** the same lesson outcome, using a USB data cable or supported browser pairing.
- **Laptop + MicroPython:** an optional separate Python editor. Uses `from microbit import *`, `display.show` and a supplied button-listening loop. The loop is explained as provided scaffolding; writing selection/loops independently is not a Week 2 success criterion.

MicroPython is deliberately not offered as the iPad route in this introductory lesson. This is a teaching simplification, not a claim that every advanced MicroPython/iPad transfer workflow is impossible.

The iPad transfer card links to current official guidance. The MakeCode app can prompt for Bluetooth mode for each transfer. The official guide describes triple reset or the A+B/reset alternative; follow the current app prompt. Browser-to-app handoff is documented for Chrome, not Safari. If a micro:bit previously ran MicroPython, a teacher may need to load a fresh MakeCode program from a computer before it will pair reliably.

Editor URLs are constants in `lesson.js` (`LINKS`). Instructions say exactly which editor area to use. Code is never entered into a lesson response box. A full small working model is intentional: students first experience success, then personalise, test and explain it.

### Before class

1. Test the school iPad app, Bluetooth permissions, battery packs and transfer on the actual managed devices. Use numbered devices and avoid pairing to a neighbour’s board.
2. Prepare fresh MakeCode programs on boards that previously used MicroPython, if pairing needs this.
3. Test laptop USB data cables. Prepare spares and a simulator-only contingency.
4. Provide A4 paper for extensions. Agree pair roles; swap after the first successful run.
5. Prepare the Teams Assignment **Week 2 Project**.
6. Demonstrate one tab/app switch and a single simulator test to the class. For first-time users, offer Blocks as the default starting route.
7. Remind students: dry table; hold board edges; insert the micro USB plug straight into the top port; do not pull the wire; do not interrupt transfer; report heat or damage; do not wear a bare board against skin.

### Assessment, progression and avoiding lockouts

- The starter and plenary each have one concept check, with specific feedback and another attempt available. Incorrect answers do not lock navigation.
- Free writing is saved for teacher review; there are no required keywords or minimum essay lengths. Short bilingual explanations are allowed.
- Continue points out missing evidence. Students can explicitly choose **Continue — mark for review**. This records an incomplete/needs-review status, not a fabricated pass.
- Opening a card is not completion. Editing an answer invalidates that card’s previous recorded status and any stale automatic feedback.
- Changing the device, editor or badge choices clears relevant current test selections, preserving the previous results in the history. Students are asked to retest.
- Hardware failure is separate from conceptual misunderstanding. A simulator-only or support-needed outcome is recorded honestly.
- Teachers assess the two observed behaviours, the student’s explanation, the change/test record and images/live demonstration. “Recorded” is not a mastery certificate.

### Language and accessibility

Entry offers English, English + Simplified Chinese, English + Korean, and English + Bahasa Melayu. Bilingual task support appears on every card and the two concept checks have translated explanations. The compact header language button and glossary remain available. These are authored classroom supports, not a live translation service; review wording with bilingual staff where possible. Code and official editor names stay unchanged.

The interface uses local Raleway (OFL licence included) with system fallbacks for CJK glyphs, labelled controls, native keyboard-operable choices/dialogs, visible focus, 44px touch controls, reduced-motion support and responsive layouts. WAGBA and KSU remain visible in the sticky learning header, alongside the labelled lesson journey and an Export PDF button. No timed exam restrictions or inaccessible drag-and-drop are used.

### Saving, evidence and privacy

- Lightweight answers/history use `localStorage`; images use `IndexedDB`.
- Storage keys start `y8w2project.v3.`. Student profiles are separated by normalised name/class. Teacher storage uses a separate key.
- The old `y8-w2-project-student` / teacher storage is not deleted. Matching old text/checks are preserved as a labelled legacy appendix when a new profile starts. Old images remain in their old browser keys; use the old app/backup if you need those image records.
- Uploaded or pasted PNG/JPEG/WebP images up to 12 MB are resized to a maximum 1600px and saved as compressed JPEG. Check that code remains readable. HEIC/SVG files are not accepted; use screenshots or JPEG export.
- Captions, timestamps, responses, revised answers, concept-check attempts and submitted snapshots are retained. The app records learning inputs, not every keystroke or unrelated browsing.
- If storage fails, a visible warning replaces “Saved”. Evidence may survive only for the current tab; download a backup immediately.
- Paste uses the Clipboard API where permitted, with a keyboard-paste area and file-upload alternative. iPad/browser policies may prevent direct clipboard image access.
- No uploaded images or responses are sent to a server by the lesson. External editor links have their own service/privacy policies. Do not include faces, full names in badge output, passwords or other students’ private information in evidence.
- Same-browser storage is not encrypted or access-controlled. On shared devices, the school must manage sign-out/clearing and retention. A different browser, different hosting origin or cleared browser data will not share this progress.

### Backup and restore

Lesson menu → **Download progress backup** creates one JSON file containing lesson/version, student details, latest responses, history, statuses and the compressed image data. Keep the file private. This is the portable restore mechanism; a PDF cannot restore editable progress.

Use **Restore backup** on entry or in the menu. Lesson/version and image formats are validated, and confirmation is required before replacing that profile. Images are written into a new evidence session before the current profile is replaced. Wrong-lesson, damaged and oversized backups are rejected without replacing the current profile.

Reset requires confirmation and affects the active version 3 profile, not every student or the old app’s storage. A saved JSON backup can restore it. If browser storage itself is failing, deletion cannot always be confirmed; use managed browser controls for secure cleanup.

### PDF and Teams

Lesson menu → **Export current progress as PDF** works at any point; the review card also has a prominent export button. The app prepares a full print report, including unfinished stages, objectives, student details, answers, earlier attempts/corrections and image evidence.

The PDF method is the browser’s print engine (`window.print()`): choose **Save as PDF**. It supports Unicode text and avoids a CDN/PDF font dependency. On iPad, use the print preview/share options to save to Files. The ordinary browser Print command is also a fallback after entering the lesson.

Suggested filename: `Year8_Class_Full_Name_T1W2_Project.pdf`. The app sets the document title, but the final filename/location is controlled by the browser and must be checked. For page numbering, enable the browser’s print headers/footers if offered. A4 print styling uses readable fonts and flowing text; verify the print preview before saving, particularly for unusually long answers.

After export is requested, the app instructs students to upload the **PDF** to **Week 2 Project** in Microsoft Teams. The app cannot confirm that a PDF was saved or upload it to Teams automatically. It never reports an unverified download as successful.

### Files and images

- `index.html`: landing page and small app shell.
- `styles.css`: monochrome-first layout and print styles.
- `lesson.js`: learning intentions, card spine, route-specific examples, languages, progress/backup rules.
- `reflections.js`: matched Year 8 KSU checks, bilingual guidance and before/after report comparison.
- `views.js`: focused card content and complete evidence-report template.
- `app.js`: navigation, entry, saving, evidence, import/export and feedback.
- `assets/`: existing artwork, school learning posters and local font.
- `tests/lesson-regression.cjs`: non-browser regression tests (optional developer tool; not needed by students).
- `DESIGN_REVIEW.md`: post-redesign pedagogical review and classroom checks.

Reused on screen: the badge scenario, the optional simulator-actions illustration and the two school learning posters. The remaining older images are retained as source assets, not displayed. In particular, the old transfer picture appears to depict a full-sized USB connector at the board; it is not used for safety instruction. The old multi-stage planning pictures and mixed-Python image are not put back into the focused cards.

### Real MakeCode examples (visual update 3.1)

Five screenshots in `assets/images/makecode/` were captured from the official MakeCode editor, using a separate teaching-example project. They are not generated illustrations or HTML imitation blocks:

- `01-on-start-heart.jpg`: first working example; shows where the icon snaps into startup.
- `02-startup-and-button-a.jpg`: starter and main badge model; shows two separate event stacks.
- `03-button-b-extension.jpg`: optional Level 1 hint; a close-up of B only. The caption explicitly says to keep startup and A.
- `04-misplaced-output-debugging.jpg`: Level 2 deliberately incorrect placement, clearly labelled so students do not copy it as the solution.
- `05-editor-workspace.jpg`: optional setup orientation showing simulator, toolbox and workspace.

The screenshots use fixed reference values (heart, AB, tick). The badge card tells students to substitute their own saved icon and message. Python examples remain copyable text in the selected dialect; a collapsed comparison shows equivalent block behaviour, not Python syntax. Screenshots preserve their proportions and can be enlarged; written placement instructions remain available if an image fails.

The prominent **Open MakeCode** button is on setup, build, test and extension cards. It opens the official editor, not a pre-filled project. Students should return to their existing project if already open. iPad cards explicitly prioritise the micro:bit app and label the browser button as an alternative. The optional laptop MicroPython route has its own clearly named editor button. No saved-progress version or storage key changed in this visual update.

### Verification and remaining checks

The bundled tests exercise state transitions, entry validation, teacher separation, saving, restore, invalid-backup protection, optional extensions, card markup, input/report coverage, safe escaping, language coverage and print-report preparation. They also parse all Python examples and exercise MakeCode event behaviour against API stubs.

For visual update 3.1, the block examples were converted and inspected in the actual MakeCode editor, and each screenshot was checked for complete, readable blocks. The automated tests also check screenshot dimensions/references, personalised captions, safe external links and report separation from teaching examples. This does not validate every Python sample in a real compiler or a physical device.

The lesson app itself has **not** received rendered browser viewport, real clipboard, physical iPad/Bluetooth or print-pagination testing; local browser navigation was restricted during the redesign. Before class, manually check 1366×768, 1920×1080, tablet landscape and portrait; keyboard navigation; a real uploaded/pasted screenshot; refresh; backup restore; and PDF preview on the managed devices.

### Sources consulted

- [MakeCode name badge project](https://makecode.microbit.org/projects/name-badge) — small steps, placement instructions and simulator testing.
- [MakeCode button events](https://makecode.microbit.org/reference/input/on-button-pressed) — event behaviour and simulator buttons.
- [MakeCode Python and MicroPython](https://support.microbit.org/support/solutions/articles/19000111744-makecode-python-and-micropython) — separate dialects/editors.
- [micro:bit iPad/iPhone app guidance](https://support.microbit.org/support/solutions/articles/19000117215-micro-bit-ios-app-creating-and-sending-programs-on-an-apple-ipad-or-iphone) — app, Bluetooth and browser-to-app handoff.
- [micro:bit mobile guide](https://microbit.org/get-started/user-guide/mobile/) — device route and troubleshooting.
- [Raspberry Pi Foundation: Explore, Design, Invent](https://www.raspberrypi.org/blog/free-coding-resources-children-young-people-digital-making-independence/) — scaffolded progression towards independent decisions.

The app is not affiliated with CAT4, Testwise, Khan Academy or Raspberry Pi. Its design borrows the general principle of focused steps, not proprietary assessment screens or a claim of equivalent measured effectiveness.
