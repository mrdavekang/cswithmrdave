"""Run this file in IDLE after saving your changes to fitness_practice_b.py."""

from contextlib import redirect_stdout
from io import StringIO
from unittest.mock import patch

from practice_test_support import limited_call, load_practice


CASES = (
    ("Normal input", ("60",), 60),
    ("Lower limit", ("1",), 1),
    ("Upper limit", ("180",), 180),
    ("Two invalid entries then valid", ("181", "182", "180"), 180),
    ("Below the limit then valid", ("0", "1"), 1),
)


def run_case(enter_duration, label, entries, expected):
    print(f"\n{label} | inputs: {' then '.join(entries)}")
    answers_used = 0
    transcript = StringIO()
    after_entry = 0
    first_prompt = ""
    retry_feedback = []

    def supply_input(prompt=""):
        nonlocal answers_used, after_entry, first_prompt
        if answers_used == len(entries):
            raise ValueError("The routine asked for another input when it should have returned.")
        if answers_used == 0:
            first_prompt = str(prompt).strip()
        else:
            printed_feedback = transcript.getvalue()[after_entry:].strip()
            different_prompt = str(prompt).strip() not in ("", first_prompt)
            retry_feedback.append(bool(printed_feedback or different_prompt))
        value = entries[answers_used]
        answers_used += 1
        print(f"{prompt}{value}")
        after_entry = transcript.tell()
        return value

    try:
        with redirect_stdout(transcript), patch("builtins.input", side_effect=supply_input):
            actual = limited_call(enter_duration)
    except Exception as error:
        print_transcript(transcript)
        print(f"FAIL | {type(error).__name__}: {error}")
        return False

    print_transcript(transcript)
    feedback_seen = len(retry_feedback) == len(entries) - 1 and all(retry_feedback)
    correct = (type(actual) is int and actual == expected
               and answers_used == len(entries) and feedback_seen)
    print(f"Expected: {expected} | Returned: {actual!r} | Inputs read: {answers_used}/{len(entries)}")
    if answers_used < len(entries):
        print("The routine returned before it had read all the required inputs.")
    elif not feedback_seen:
        print("No error feedback was visible before at least one retry.")
    print("PASS" if correct else "FAIL")
    return correct


def print_transcript(transcript):
    lines = transcript.getvalue().splitlines()
    for line in lines[:12]:
        print(line)
    if len(lines) > 12:
        print("Additional repeated output omitted.")


def main():
    enter_duration = load_practice(__file__, "fitness_practice_b.py")["EnterDuration"]
    print("SECTION B | EnterDuration")
    print("Inputs are supplied by the runner. Do not type into the shell.")
    passed = sum(run_case(enter_duration, *case) for case in CASES)
    print(f"\nResult: {passed}/{len(CASES)} tests passed.")
    print("Check that the feedback explains why each invalid entry was rejected.")
    return passed == len(CASES)


if __name__ == "__main__":
    main()
