"""Shared runner helpers. Students do not need to edit this file."""

from pathlib import Path
from runpy import run_path
import sys


def load_practice(runner_path, practice_filename):
    # Read the saved source on every run, even after a quick edit.
    return run_path(str(Path(runner_path).resolve().with_name(practice_filename)))


class PracticeStopped(RuntimeError):
    pass


def limited_call(function, *args):
    """Stop common infinite loops in a student's practice function."""
    filename = function.__code__.co_filename
    lines_left = 600

    def trace_student_line(frame, event, arg):
        nonlocal lines_left
        if event == "line":
            lines_left -= 1
            if not lines_left:
                raise PracticeStopped("Too many steps. Check your loop condition and whether its values change.")
        return trace_student_line

    def select_frame(frame, event, arg):
        if event == "call" and frame.f_code.co_filename == filename:
            return trace_student_line
        return None

    previous = sys.gettrace()
    sys.settrace(select_frame)
    try:
        return function(*args)
    finally:
        sys.settrace(previous)
