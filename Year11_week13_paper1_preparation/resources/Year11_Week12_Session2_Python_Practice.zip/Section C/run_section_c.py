"""Run this file in IDLE after saving your changes to fitness_practice_c.py."""

from contextlib import redirect_stdout
from io import StringIO
from unittest.mock import patch

from practice_test_support import limited_call, load_practice


CASES = (
    ("Longest is last", [30, 45, 60], 60),
    ("Longest is first", [75, 30], 75),
    ("Empty log", [], 0),
)


def make_records(exercise, durations):
    log = []
    for index, duration in enumerate(durations):
        activity = exercise()
        activity.DayNo = index + 1
        activity.Duration = duration
        activity.Distance = float(index + 2)
        log.append(activity)
    return log


def run_case(exercise, longest_duration, label, durations, expected):
    print(f"\n{label} | durations: {durations}")
    transcript = StringIO()
    try:
        records = make_records(exercise, durations)
        with redirect_stdout(transcript), patch("builtins.input", side_effect=ValueError(
                "Use the supplied ActivityLog; the function should not ask for input.")):
            actual = limited_call(longest_duration, records)
    except Exception as error:
        print(f"FAIL | {type(error).__name__}: {error}")
        return False

    printed = bool(transcript.getvalue())
    correct = type(actual) is int and actual == expected and not printed
    print(f"Expected: {expected} | Returned: {actual!r}")
    if printed:
        print("The function printed output. Return the result and let the runner display it.")
    if actual is None:
        print("No value was returned. Check the function's return statement.")
    print("PASS" if correct else "FAIL")
    return correct


def main():
    practice = load_practice(__file__, "fitness_practice_c.py")
    exercise = practice["Exercise"]
    longest_duration = practice["LongestActivityDuration"]
    print("SECTION C | LongestActivityDuration")
    print("The runner makes its own Exercise records. No input is needed.")
    passed = sum(run_case(exercise, longest_duration, *case) for case in CASES)
    print(f"\nResult: {passed}/{len(CASES)} tests passed.")
    return passed == len(CASES)


if __name__ == "__main__":
    main()
