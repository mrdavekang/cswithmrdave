Numbers = [1, 3, 2, -5]
# Part 1: write your solution below.

# Part 3 example: [22, 7, 1, 121, 11]
