Durations = [12, 30, 45, 20]
Choice = "2"
if Choice == "1":
    print("Sessions:", len(Durations))
elif Choice == "2":
    Count = 0
    for Duration in Durations:
        if Duration >= 30:
            Count = Count + 1
    print("Long sessions:", Count)
else:
    print("Unknown choice")
